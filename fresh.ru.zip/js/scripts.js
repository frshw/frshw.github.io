// Пример скрипта для анимации на скролле (lazy load эффект)
document.addEventListener('DOMContentLoaded', () => {
    const sections = document.querySelectorAll('section');

    const options = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = 1;
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, options);

    sections.forEach(section => {
        observer.observe(section);
    });
});


// Ждем загрузки страницы и убираем прелоадер
window.onload = function () {
    document.body.classList.remove('loading');
};

// ScrollReveal анимации для элементов
ScrollReveal().reveal('#about', {
    delay: 500,
    duration: 1000,
    origin: 'bottom',
    distance: '50px',
});

// Плавный переход по якорям
document.querySelectorAll('.scroll-link').forEach(link => {
    link.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        window.scrollTo({
            top: target.offsetTop,
            behavior: 'smooth'
        });
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const newsCards = document.querySelectorAll('.news-card');

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            const category = button.getAttribute('data-category');

            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            newsCards.forEach(card => {
                card.style.display =
                    category === 'all' || card.getAttribute('data-category') === category
                        ? 'block'
                        : 'none';
            });
        });
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', async function (e) {
            e.preventDefault(); // Остановка перезагрузки страницы

            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const message = document.getElementById('message').value;

            const response = await fetch('process_form.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `name=${encodeURIComponent(name)}&email=${encodeURIComponent(email)}&message=${encodeURIComponent(message)}`,
            });

            const result = await response.text();
            const formMessage = document.getElementById('formMessage');

            if (formMessage) {
                if (result === 'success') {
                    formMessage.style.display = 'block';
                    formMessage.textContent = 'Сообщение успешно отправлено!';
                    formMessage.style.color = '#00ff00';
                } else {
                    formMessage.style.display = 'block';
                    formMessage.textContent = 'Ошибка отправки. Попробуйте позже.';
                    formMessage.style.color = '#ff0000';
                }
            }

            // Очистка полей после отправки
            contactForm.reset();
        });
    }
});


document.addEventListener('DOMContentLoaded', () => {
    const container = document.querySelector('.floating-circles');
    const circles = 25; // Увеличил количество кружков

    for (let i = 0; i < circles; i++) {
        const circle = document.createElement('div');
        circle.classList.add('circle');

        // Устанавливаем случайное начальное положение и размер
        circle.style.left = `${Math.random() * 100}%`;
        circle.style.animationDuration = `${10 + Math.random() * 10}s`;
        circle.style.animationDelay = `${-Math.random() * 20}s`;
        container.appendChild(circle);

        // Добавляем эффект при наведении мыши
        circle.addEventListener('mouseover', () => {
            circle.style.opacity = '0.8';
            circle.style.transform = `scale(${1 + Math.random() * 2})`;
        });

        circle.addEventListener('mouseleave', () => {
            circle.style.opacity = '0.4';
            circle.style.transform = 'scale(1)';
        });
    }
});

// Плавное исчезновение прелоадера
window.onload = function () {
    document.body.classList.remove('loading');
};

document.addEventListener('DOMContentLoaded', () => {
    // Получаем все элементы с классом fade-in
    const fadeInElements = document.querySelectorAll('.fade-in');

    // Добавляем класс show к каждому элементу
    fadeInElements.forEach(element => {
        element.classList.add('show');
    });
});
